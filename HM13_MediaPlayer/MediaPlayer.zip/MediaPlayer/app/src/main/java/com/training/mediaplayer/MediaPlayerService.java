package com.training.mediaplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MediaPlayerService extends Service {

    private final IBinder binder = new MediaPlayerBinder();
    private MediaPlayer mediaPlayer;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public class MediaPlayerBinder extends Binder {
        public MediaPlayerService getService() {
            return MediaPlayerService.this;
        }
    }

    public void initializePlayer(int resourceId) {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, resourceId);
        }
    }

    public void play() {
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
            // Assuming placeholder song title and album art bitmap for now
            showNotification("Song Title", null);
        }
    }

    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            removeNotification();
        }
    }

    public void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
            removeNotification();
        }
    }

    public void skipNext() {
        // Placeholder for skipping to the next song logic
    }

    public void skipPrevious() {
        // Placeholder for skipping to the previous song logic
    }

    public void seekTo(int position) {
        if (mediaPlayer != null) {
            mediaPlayer.seekTo(position);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "MEDIA_PLAYBACK_CHANNEL",
                    "Media Playback",
                    NotificationManager.IMPORTANCE_LOW
            );

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildMediaNotification(String songTitle, Bitmap albumArt) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "MEDIA_PLAYBACK_CHANNEL");

        builder.setSmallIcon(R.drawable.ic_music_note) // Replace with your app's icon
                .setContentTitle(songTitle)
                .setContentIntent(createContentIntent())
                .setLargeIcon(albumArt)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .setAutoCancel(false)
                .setOngoing(true)
                .setShowWhen(false)
                .addAction(R.drawable.ic_previous, "Previous", /* PendingIntent for Previous action */)
                .addAction(R.drawable.ic_pause, "Pause", /* PendingIntent for Pause action */)
                .addAction(R.drawable.ic_next, "Next", /* PendingIntent for Next action */)
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setShowActionsInCompactView(0, 1, 2)
                );

        return builder.build();
    }

    private PendingIntent createContentIntent() {
        Intent openUI = new Intent(this, MainActivity.class);
        openUI.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return PendingIntent.getActivity(this, 0, openUI, 0);
    }

    private void showNotification(String songTitle, Bitmap albumArt) {
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, buildMediaNotification(songTitle, albumArt));
    }

    private void removeNotification() {
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.cancel(1);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            stop();
        }
        removeNotification();
    }
}
