package com.training.wafi.Truck;

public class ProgressData {
    public int progress_1;
    public int progress_2;
    public int progress_3;
}
