package com.training.wafi.Truck;

public class StockActivity {
}
