package com.training.wafi.Truck;

public class SettingsActivity {
}
