package com.training.wafi.Home;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.chip.ChipGroup;
import com.training.wafi.ConversationsActivity;
import com.training.wafi.R;
import com.training.wafi.Truck.SettingsActivity;
import com.training.wafi.Truck.StockActivity;
import com.training.wafi.Truck.TruckActivity;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private ProgressBarAdapter adapter;
    private ScrollView progressScrollView;
    private boolean progressBarsLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Sample data
        List<Integer> progressData = Arrays.asList(30, 90, 75);

        viewPager = findViewById(R.id.viewPager);
        adapter = new ProgressBarAdapter(getSupportFragmentManager(), progressData);
        viewPager.setAdapter(adapter);

        progressScrollView = findViewById(R.id.progressScrollView);
        ConstraintLayout rootLayout = findViewById(R.id.root);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.navigation_home) {
                    // Handle Home selection
                    return true;
                } else if (id == R.id.navigation_truck) {
                    startActivity(new Intent(MainActivity.this, TruckActivity.class));
                    return true;
                } else if (id == R.id.navigation_stock) {
                    startActivity(new Intent(MainActivity.this, StockActivity.class));
                    return true;
                } else if (id == R.id.navigation_settings) {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    return true;
                }
                return false;
            }
        });

        // Set onTouchListener
        rootLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    int[] location = new int[2];
                    progressScrollView.getLocationOnScreen(location);
                    Rect rect = new Rect(location[0], location[1], location[0] + progressScrollView.getWidth(), location[1] + progressScrollView.getHeight());
                    if (!rect.contains((int) event.getRawX(), (int) event.getRawY())) {
                        progressScrollView.setVisibility(View.GONE);
                        viewPager.setVisibility(View.VISIBLE);
                    }
                    v.performClick();
                }
                return false;
            }
        });

        // Set onClickListener with log statement
        rootLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Log statement to indicate the click event on the rootLayout
                Log.d("MainActivity", "RootLayout clicked");
            }
        });

        Button btnReview = findViewById(R.id.btnReview);
        btnReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayProgressBars();
            }
        });

        Button btnMessage = findViewById(R.id.btnMessage);
        btnMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start ConversationsActivity
                Intent intent = new Intent(MainActivity.this, ConversationsActivity.class);
                startActivity(intent);
            }
        });
    }

    private void displayProgressBars() {
        LinearLayout progressBarContainer = findViewById(R.id.progressBarContainer);

        if (!progressBarsLoaded) {
            List<Pair<Integer, String>> progressData = Arrays.asList(
                    new Pair<>(30, "Description 1"),
                    new Pair<>(90, "Description 2"),
                    new Pair<>(75, "Description 3")
            );

            LayoutInflater inflater = LayoutInflater.from(this);
            for (Pair<Integer, String> data : progressData) {
                View progressView = inflater.inflate(R.layout.progress_item, progressBarContainer, false);

                TextView tvDescription = progressView.findViewById(R.id.tvDescription);
                ProgressBar progressBar = progressView.findViewById(R.id.progressBar);

                tvDescription.setText(data.second);
                progressBar.setProgress(data.first);

                progressBarContainer.addView(progressView);
            }
            progressBarsLoaded = true;
        }

        if (progressScrollView.getVisibility() == View.VISIBLE) {
            progressScrollView.setVisibility(View.GONE);
            viewPager.setVisibility(View.VISIBLE);
        } else {
            progressScrollView.setVisibility(View.VISIBLE);
            viewPager.setVisibility(View.GONE);
        }
    }
}
