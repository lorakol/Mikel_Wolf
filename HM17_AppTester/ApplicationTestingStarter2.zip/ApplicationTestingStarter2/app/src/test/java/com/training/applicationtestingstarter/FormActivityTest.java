package com.training.applicationtestingstarter;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

@RunWith(AndroidJUnit4.class)
public class FormActivityTest {

    @Rule
    public ActivityTestRule<FormActivity> mActivityRule = new ActivityTestRule<>(FormActivity.class);

    @Test
    public void fillOutFormAndSave() {
        // Assuming you have EditTexts with the IDs firstName, lastName, and age.
        onView(withId(R.id.firstName)).perform(typeText("John"));
        onView(withId(R.id.lastName)).perform(typeText("Doe"));
        onView(withId(R.id.age)).perform(typeText("25"));

        // Close the keyboard (sometimes necessary if the button we want to click next is covered by the keyboard)
        onView(withId(R.id.age)).perform(closeSoftKeyboard());

        // Assuming you have a save button with the ID saveButton.
        onView(withId(R.id.saveButton)).perform(click());

        // Add assertions as needed to confirm behavior.
    }
}
