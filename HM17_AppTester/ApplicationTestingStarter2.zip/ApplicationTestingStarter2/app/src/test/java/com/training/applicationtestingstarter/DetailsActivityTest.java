package com.training.applicationtestingstarter;

public class DetailsActivityTest {
}
