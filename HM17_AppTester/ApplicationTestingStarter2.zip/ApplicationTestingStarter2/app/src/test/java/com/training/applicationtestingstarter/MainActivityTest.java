package com.training.applicationtestingstarter;


import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public IntentsTestRule<MainActivity> mActivityRule = new IntentsTestRule<>(MainActivity.class);

    @Test
    public void testPersonListFragmentEmptyState() {
        // Check if the PersonListFragment is displayed with an empty message.
        onView(withId(R.id.your_empty_view_id)).check(matches(isDisplayed()));

        // Use the add action to open the FormActivity.
        onView(withId(R.id.your_add_button_id)).perform(click());
        intended(hasComponent(FormActivity.class.getName()));
    }
}
