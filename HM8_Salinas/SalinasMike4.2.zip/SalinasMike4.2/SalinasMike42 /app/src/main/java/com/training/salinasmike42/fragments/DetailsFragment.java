package com.training.salinasmike42.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.training.salinasmike42.DatabaseHelper;
import com.training.salinasmike42.R;

import android.webkit.JavascriptInterface;


public class DetailsFragment extends Fragment {

    private WebView webViewDetails;
    private DatabaseHelper databaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_details, container, false);

        databaseHelper = new DatabaseHelper(requireContext());

        webViewDetails = view.findViewById(R.id.webViewDetails);
        webViewDetails.getSettings().setJavaScriptEnabled(true);
        webViewDetails.addJavascriptInterface(new JavaScriptInterface(), "Android");
        webViewDetails.setWebViewClient(new CustomWebViewClient());
        webViewDetails.loadDataWithBaseURL(null, getDetailsHTMLContent(), "text/html", "UTF-8", null);

        return view;
    }

    private String getDetailsHTMLContent() {
        return "<html><body>" +
                "<h1>Details Screen</h1>" +
                "<p id=\"firstName\"></p>" +
                "<p id=\"lastName\"></p>" +
                "<p id=\"age\"></p>" +
                "<button onclick=\"deleteData()\">Delete</button>" +
                "<script>" +
                "function populateData(firstName, lastName, age) {" +
                "  document.getElementById('firstName').innerText = 'First Name: ' + firstName;" +
                "  document.getElementById('lastName').innerText = 'Last Name: ' + lastName;" +
                "  document.getElementById('age').innerText = 'Age: ' + age;" +
                "}" +
                "function deleteData() {" +
                "  var firstName = document.getElementById('firstName').innerText.split(': ')[1];" +
                "  var lastName = document.getElementById('lastName').innerText.split(': ')[1];" +
                "  var age = document.getElementById('age').innerText.split(': ')[1];" +
                "  Android.deleteData(firstName, lastName, age);" +
                "}" +
                "</script>" +
                "</body></html>";
    }

    private class CustomWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // Handle custom links if needed
            return super.shouldOverrideUrlLoading(view, url);
        }
    }

    private class JavaScriptInterface {
        @JavascriptInterface
        public void populateDetails(String firstName, String lastName, int age) {
            getActivity().runOnUiThread(() -> {
                String jsCode = "javascript:populateData('" + firstName + "', '" + lastName + "', " + age + ")";
                webViewDetails.loadUrl(jsCode);
            });
        }

        @JavascriptInterface
        public void deleteData(String firstName, String lastName, int age) {
            databaseHelper.deleteItem(firstName, lastName, age);
            // Data deleted, transition back to the list screen
            getActivity().runOnUiThread(() -> {
                FragmentTransaction fragmentTransaction = getParentFragmentManager().beginTransaction();
                ListFragment listFragment = new ListFragment();
                fragmentTransaction.replace(R.id.fragment_container, listFragment);
                fragmentTransaction.commit();
            });
        }
    }
}

