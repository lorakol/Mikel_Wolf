package com.training.salinasmike42.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.training.salinasmike42.R;

public class ListFragment extends Fragment {

    private WebView webViewList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);

        webViewList = view.findViewById(R.id.webViewList);
        webViewList.getSettings().setJavaScriptEnabled(true);
        webViewList.setWebViewClient(new CustomWebViewClient());
        webViewList.loadDataWithBaseURL(null, generateListItems(), "text/html", "UTF-8", null);

        return view;
    }

    private String generateListItems() {
        StringBuilder sb = new StringBuilder();
        sb.append("<html><body><h1>List Screen</h1><ul>");

        // Generate list items dynamically with custom links
        sb.append("<li><a href=\"my-app-schema://details-screen?first=John&last=Doe&age=25\">John Doe</a></li>");
        sb.append("<li><a href=\"my-app-schema://details-screen?first=Jane&last=Smith&age=30\">Jane Smith</a></li>");
        sb.append("<li><a href=\"my-app-schema://details-screen?first=Mike&last=Johnson&age=35\">Mike Johnson</a></li>");

        sb.append("</ul></body></html>");

        return sb.toString();
    }

    private class CustomWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url.startsWith("my-app-schema://details-screen")) {
                // Extract the link parameters from the URL

                // Transition to the details screen and pass the extracted data
                FragmentTransaction fragmentTransaction = getParentFragmentManager().beginTransaction();
                DetailsFragment detailsFragment = new DetailsFragment();

                // Pass the extracted data to the detailsFragment using bundle or setter methods

                fragmentTransaction.replace(R.id.fragment_container, detailsFragment);
                fragmentTransaction.commit();
                return true;
            }

            return super.shouldOverrideUrlLoading(view, url);
        }
    }
}



