package com.training.digginggame.activity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.training.digginggame.GameBoardView;
import com.training.digginggame.GameModel;
import com.training.digginggame.R;

public class GameActivity extends AppCompatActivity {

    private GameModel gameModel;
    private GameBoardView gameBoardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        gameModel = new GameModel();
        gameBoardView = new GameBoardView(this, gameModel);
        setContentView(gameBoardView);

        // Other initialization...
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.game_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.inventoryMenu) {
            // Start InventoryActivity here
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
