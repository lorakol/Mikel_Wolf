package com.training.digginggame.object;

import android.graphics.Bitmap;

public class Item {
    public String name;
    public int value;
    public Bitmap texture;
    public boolean isFound;
}
