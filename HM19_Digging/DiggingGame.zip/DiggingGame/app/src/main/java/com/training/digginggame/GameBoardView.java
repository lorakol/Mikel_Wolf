package com.training.digginggame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.training.digginggame.object.Item;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameBoardView extends SurfaceView implements SurfaceHolder.Callback {
    private Bitmap groundTexture;
    private Bitmap holeTexture;
    private List<Item> items = new ArrayList<>();
    private Paint paint = new Paint();

    GameModel gameModel = new GameModel();
    public GameBoardView(Context context, GameModel model) {
        super(context);
        this.gameModel = model;
        // Initialization...
    }
    public GameBoardView(Context context) {
        super(context);
        init();
    }

    public GameBoardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        getHolder().addCallback(this);
        groundTexture = BitmapFactory.decodeResource(getResources(), R.drawable.field);
        holeTexture = BitmapFactory.decodeResource(getResources(), R.drawable.hole);
        paint.setAntiAlias(true);
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

    private void drawGameBoard() {
        Canvas canvas = null;
        try {
            canvas = getHolder().lockCanvas();
            if (canvas != null) {
                // Fill the canvas with the ground texture
                canvas.drawBitmap(groundTexture, 0, 0, paint);

                // Draw items and holes (this is a simplistic approach)
                for (Item item : items) {
                    if (item.isFound) {
                        canvas.drawBitmap(item.texture, item.x, item.y, paint);
                    } else {
                        canvas.drawBitmap(holeTexture, item.x, item.y, paint);
                    }
                }
            }
        } finally {
            if (canvas != null) {
                getHolder().unlockCanvasAndPost(canvas);
            }
        }
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            handleTap(event.getX(), event.getY());
        }
        return true;
    }

    private void handleTap(float x, float y) {
        // Check for items within a certain radius of the tap
        for (Item item : items) {
            if (Math.sqrt(Math.pow(item.x - x, 2) + Math.pow(item.y - y, 2)) < DIG_RADIUS) {
                item.isFound = true;
                // Show a toast with the found item
                Toast.makeText(getContext(), "Found: " + item.name, Toast.LENGTH_SHORT).show();
            }
        }
        drawGameBoard();  // Refresh the board to reflect the changes
    }

    private List<Item> parseCSV(Context context) {
        List<Item> items = new ArrayList<>();
        InputStream inputStream = context.getResources().openRawResource(R.raw.items);
        // Assuming your CSV file is named treasure_data.csv and placed in the res/raw directory.

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;

        try {
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {  // Basic check to ensure we have both name and value
                    Item item = new Item();
                    item.name = parts[0].trim();
                    item.value = Integer.parseInt(parts[1].trim());
                    // Assuming each line in your CSV has the format: "itemName,value"
                    items.add(item);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return items;
    }

    private void initializeItems(Context context) {
        List<Item> parsedItems = parseCSV(context);

        for (Item item : parsedItems) {
            item.texture = BitmapFactory.decodeResource(getResources(), R.drawable.some_default_texture);
            // Assign a random position to each item on the game board.
            item.x = randomPosition();  // Create a method to generate random positions
            item.y = randomPosition();
        }

        items.addAll(parsedItems);  // Assuming 'items' is the global list of items in the game board.
    }

    private int randomPosition() {
        // Returns a random position within the bounds of the game board.
        return new Random().nextInt(GAME_BOARD_SIZE);  // Assuming GAME_BOARD_SIZE is the maximum coordinate value.
    }


}
