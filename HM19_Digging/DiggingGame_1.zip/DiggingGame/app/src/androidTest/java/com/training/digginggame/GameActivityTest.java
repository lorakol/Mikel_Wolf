package com.training.digginggame;

//import androidx.test.rule.ActivityTestRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.espresso.Espresso;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.matcher.ViewMatchers.*;

import com.training.digginggame.activity.GameActivity;

@RunWith(AndroidJUnit4.class)
public class GameActivityTest {

//    @Rule
//    public ActivityTestRule<GameActivity> activityRule = new ActivityTestRule<>(GameActivity.class);
//
//    @Test
//    public void testGameStart() {
//        Espresso.onView(withId(R.id.gameBoardView)) // replace with your actual view id
//                .perform(click());
//        // Add assertions or further interactions.
//    }

    // ... other tests
}
