package com.training.unittestingstarter;

import android.view.Menu;
import android.view.MenuItem;

import androidx.fragment.app.FragmentTransaction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.training.unittestingstarter.fragment.FormFragment;
import com.training.unittestingstarter.object.Person;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(AndroidJUnit4.class)
public class FormActivityTest {

    @Rule
    public ActivityTestRule<FormActivity> activityRule = new ActivityTestRule<>(FormActivity.class);

    @Mock
    FormFragment formFragment;

    @Mock
    Menu menu;

    @Mock
    MenuItem menuItem;

    @Mock
    FragmentTransaction fragmentTransaction;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        // Assuming R.id.action_save is 1 for simplification
        when(menuItem.getItemId()).thenReturn(1);
    }

    @Test
    public void testOnOptionsItemSelected_saveAction() {
        FormActivity activity = activityRule.getActivity();

        // Set up our mock fragment to return a mock person when getPersonFromLayout() is called
        when(formFragment.getPersonFromLayout()).thenReturn(new Person());

        // Call the onOptionsItemSelected method with our mock MenuItem
        activity.onOptionsItemSelected(menuItem);

        // Verify that savePerson was called on the PersonStorageUtil
        // You might need to change this part depending on your setup. For example, you might need to use an argument captor to capture the actual person passed to savePerson.
        verify(formFragment).getPersonFromLayout();
    }

    // TODO: Add more tests as necessary.
}
