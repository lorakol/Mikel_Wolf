package com.training.mdv348o_ce02;

package com.example.androidtvapp.ui;

import android.os.Bundle;
import android.support.v17.leanback.app.VerticalGridSupportFragment;
import android.support.v17.leanback.widget.ArrayObjectAdapter;
import android.support.v17.leanback.widget.FocusHighlight;
import android.support.v17.leanback.widget.GridLayoutManager;
import android.support.v17.leanback.widget.OnItemViewClickedListener;
import android.support.v17.leanback.widget.Presenter;
import android.support.v17.leanback.widget.VerticalGridPresenter;

import com.example.androidtvapp.data.Movie;
import com.example.androidtvapp.data.MovieList;
import com.example.androidtvapp.presenter.CardPresenter;

import java.util.List;

public class MainFragment extends VerticalGridSupportFragment {

    private static final int NUM_COLUMNS = 5;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MovieList movieList1 = createMovieList1(); // Custom data for category 1
        MovieList movieList2 = createMovieList2(); // Custom data for category 2
        MovieList movieList3 = createMovieList3(); // Custom data for category 3

        ArrayObjectAdapter adapter = new ArrayObjectAdapter(new CardPresenter());

        adapter.addAll(0, movieList1.getMovies());
        adapter.addAll(movieList1.getMovies().size(), movieList2.getMovies());
        adapter.addAll(movieList1.getMovies().size() + movieList2.getMovies().size(), movieList3.getMovies());

        setTitle("Android TV App");
        setAdapter(adapter);
        setOnItemViewClickedListener(new ItemViewClickedListener());
        setupGrid(NUM_COLUMNS);
    }

    private MovieList createMovieList1() {
        // Custom data for category 1
        MovieList movieList = new MovieList();
        movieList.addMovie(new Movie("Movie 1", "Description for Movie 1", R.drawable.bg_movie1, R.drawable.card_movie1));
        movieList.addMovie(new Movie("Movie 2", "Description for Movie 2", R.drawable.bg_movie2, R.drawable.card_movie2));
        movieList.addMovie(new Movie("Movie 3", "Description for Movie 3", R.drawable.bg_movie3, R.drawable.card_movie3));
        movieList.addMovie(new Movie("Movie 4", "Description for Movie 4", R.drawable.bg_movie4, R.drawable.card_movie4));
        movieList.addMovie(new Movie("Movie 5", "Description for Movie 5", R.drawable.bg_movie5, R.drawable.card_movie5));
        return movieList;
    }

    private MovieList createMovieList2() {
        // Custom data for category 2
        // Add your custom movies here
    }

    private MovieList createMovieList3() {
        // Custom data for category 3
        // Add your custom movies here
    }

    private class ItemViewClickedListener implements OnItemViewClickedListener {
        @Override
        public void onItemClicked(Presenter.ViewHolder itemViewHolder, Object item,
                                  android.support.v17.leanback.widget.RowPresenter.ViewHolder rowViewHolder,
                                  android.support.v17.leanback.widget.Row row) {
            // Handle item click here, e.g., navigate to details screen
        }
    }
}
