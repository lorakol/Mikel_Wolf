package com.training.mdv348o_ce02;



import android.support.v17.leanback.widget.AbstractDetailsDescriptionPresenter;

import androidx.recyclerview.widget.RecyclerView;


public class DetailsDescriptionPresenter extends AbstractDetailsDescriptionPresenter {

    @Override
    protected void onBindDescription(RecyclerView.ViewHolder viewHolder, Object item) {
        Movie movie = (Movie) item;
        if (movie != null) {
            viewHolder.getTitle().setText(movie.getTitle());
            viewHolder.getSubtitle().setText(movie.getDescription());
        }
    }
}
