//
//  ViewController.swift
//  MDV348O_Week1
//
//  Created by Natividad Michael Salinas II on 7/5/23.
//

import UIKit


import CoreBluetooth

class ViewController: UIViewController, CBPeripheralManagerDelegate {
	
	@IBOutlet weak var button_1: UIButton!
	@IBOutlet weak var button_2: UIButton!
	@IBOutlet weak var button_3: UIButton!
	@IBOutlet weak var button_4: UIButton!
	@IBOutlet weak var button_5: UIButton!
	@IBOutlet weak var button_6: UIButton!
	
	let serviceUUID = CBUUID(string: "06B280C1-419D-4D87-810E-00D88B506717")
	let characteristicUUID = CBUUID(string: "CD570797-087C-4008-B692-7835A1246377")
	
	var characteristic: CBMutableCharacteristic!
	var peripheralManager: CBPeripheralManager!
	
	override func viewDidLoad() {
		super.viewDidLoad()
		enableButtons(false)
		peripheralManager = CBPeripheralManager(delegate: self, queue: nil)
		
	}
	
	
	func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
		switch peripheral.state {
		case .poweredOn:
			characteristic = CBMutableCharacteristic(type: characteristicUUID, properties: [.notify], value: nil, permissions: [.readable])
			let service = CBMutableService(type: serviceUUID, primary: true)
			service.characteristics = [characteristic]
			
			peripheralManager.add(service)
			peripheralManager.startAdvertising([CBAdvertisementDataServiceUUIDsKey: [serviceUUID]])
		case .poweredOff, .resetting, .unauthorized, .unknown, .unsupported:
			print("Peripheral is not available.")
		default:
			break
		}
	}
	func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
		print("Central subscribed to the characteristic")
		enableButtons(true)
	}
	
	func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
		print("Central unsubscribed from the characteristic")
		enableButtons(false)
	}
	
	@IBAction func buttonPressed(_ sender: UIButton) {
		guard let buttonTitle = sender.titleLabel?.text, let buttonValue = UInt8(buttonTitle) else { return }
		//let buttonv = UTF8(buttonTitle)
		
		let buttonValueData =  buttonTitle.data(using: .utf8)!
		peripheralManager.updateValue(buttonValueData, for: characteristic, onSubscribedCentrals: nil)
	}
	
	func enableButtons(_ enabled : Bool) {
		button_1.isEnabled = enabled
		button_2.isEnabled = enabled
		button_3.isEnabled = enabled
		button_4.isEnabled = enabled
		button_5.isEnabled = enabled
		button_6.isEnabled = enabled
	}
	
	
	
}


